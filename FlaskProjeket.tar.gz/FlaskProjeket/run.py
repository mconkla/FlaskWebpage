
from flask import Flask, render_template, request
from datetime import datetime
import csv

now = datetime.now()
date = now.strftime("%d.%m.%y")
uhr = now.strftime("%H:%M:%S")
app = Flask(__name__)

class Item():
    def __init__(self, name, amount):
        self.name = name
        self.amout = amount

class Student():
    def __init__(self,vorname, nachname, semester, fach):
        self.vorname = vorname
        self.nachname = nachname
        self.semester = semester
        self.fach = fach

@app.route("/")
def index():


    items = [
        Item("Apfel", 5),
        Item("Birne", 7),
        Item("Computer", 1)
    ]
    out = render_template("index.html", items=items)

    return out

@app.route("/time")
def hello():

    item = []
    with open("date.csv" , "r", newline='') as file:
        reader = csv.reader(file, delimiter=',')
        for element in reader:
            item.append(element)
    out = render_template("start.html", name="Max Mustermann",items = item,  zeit = date, uhr = uhr)
    return out



@app.route("/test")
def test():
    suche = request.args.get("suche", "").lower()
    give = []
    score = []

    with open("Daten.csv" , "r", newline='') as file:
        reader = csv.reader(file, delimiter=',')
        for element in reader:
            score.append(Student(element[0],element[1],element[2],element[3]))

        try:
            for search in score:
                if suche in (search.vorname +" " +  search.nachname +search.semester + search.fach).lower():
                    give.append(search)
        except TypeError:
            print("No Arguments")

    return render_template("test.html", suche = suche, give = give)

@app.route("/regist")
def register():
    email = request.args.get("email", "")
    reason = request.args.get("reason", "")
    mssge = request.args.get("mssge", "")

    return render_template("register.html", email = email, reason = reason, mssge = mssge)

@app.route("/studreg")
def studreg():
    #class Student():
    vorname = request.args.get("vorname","")
    nachname = request.args.get("nachname","")
    fach = request.args.get("fach","---")
    semester = request.args.get("semester","1")
    succes = '0'
    if vorname != "" and nachname != "" and fach != "---":
        temp = Student(vorname, nachname, semester, fach)
        with open('/home/oem/Desktop/FlaskProjeket/Daten.csv', 'a', newline='') as csvfile:
            writer = csv.writer(csvfile, delimiter=',', quotechar='"')
            writer.writerow([temp.vorname, temp.nachname, temp.semester, temp.fach])
        succes = '1'
    return render_template("studreg.html", vorname = vorname, nachname = nachname, fach = fach , semester = semester, succes = succes)

@app.route("/score")
def score():

    score = []
    with open("Daten.csv" , "r", newline='') as file:
        reader = csv.reader(file, delimiter=',')
        for element in reader:
            score.append(Student(element[0],element[1],element[2],element[3]))
    return render_template("score.html", student = score)
